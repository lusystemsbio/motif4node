# 4node
network generation through enrichment statistics
all work done in R/3.6.3

Folders contain code for different parts of project and README files describing code
TPOS contains topoloy files for all 4node circuits
MOTIF contains code to analyze motif enrichemnt for triangular and linear scores
RSET contains code to simulate 4node circuits
